#!/home/qqky020/miniconda3/bin/python


#URL
#import urllib.request
#urllib.request.urlopen('https://www.google.com')

#port
import socket
s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#location=(("10.2.58.53",3389)) #rdp to uat host 3
#location=(("10.2.58.53",1433)) #sql to uat host 3
#location=(("ITAHDNASUATRAD3",1433)) #sql to uat host 3
#location=(("ITAHDNASUATRAD3",80)) #sql to uat host 3
#location=(("10.2.58.27",3306)) #mysql AIQ 
location=(("mvashhdnradp1",1433)) #sql to uat host 3

result_of_check=s.connect_ex(location)

if result_of_check == 0:
    print("Port is open")
else:
    print("Port NOT is open")

#print('final end')


