import getpass

""" USER Check """
def usercheck():
    if getpass.getuser() != "YOURUSERNAME":
        print ("To run this script switch your current user to ${USER}}!\nsu - ${USER}; or update the usrch.py script")
        exit()
