import subprocess, os

#def t_maint(maint):
    # check maint file if resource that runs the service is silenced currently
    # return maint_t

def t_stat():
    #telegraf_ps_command = "ps -ef |grep -i telegraf_dummy |grep -v grep" # or replace with 'systemctl status telegraf'

    # bash commands:
    logfile = "/home/${USER}/UI/flask_wapi/telegraf_uptime.log"

    telegraf_processes_c = ("tail -5 "+logfile+"| sort -u | wc -l")
    telegraf_processes_running_c = ("tail -5 "+logfile+" | grep telegraf | grep OK | wc -l")
    telegraf_processes_o_c = ("tail -5 "+logfile+" | grep telegraf | grep -v OK")

    # variables with values:
    #status, telegraf_ps_command_status = subprocess.getstatusoutput(telegraf_ps_command)
    status, telegraf_processes = subprocess.getstatusoutput(telegraf_processes_c)
    status, telegraf_processes_running = subprocess.getstatusoutput(telegraf_processes_running_c)
    status, telegraf_processes_o = subprocess.getstatusoutput(telegraf_processes_o_c)

    #print ("processes",telegraf_processes,"\n\nrunning",telegraf_processes_running,"\n\noutage:\n",telegraf_processes_o,"\n\n\n")

    if telegraf_processes_running == 0:
        telegraf_status = 0
        tc = "down"  # red
        #print (telegraf_status, tc, "RED")
        return (telegraf_status, tc)
    elif telegraf_processes > telegraf_processes_running:
        telegraf_status = telegraf_processes_o
        tc = "outage"  # yellow
        #print (telegraf_status, tc, "YELLOW")
        return (telegraf_status, tc)
    elif telegraf_processes == telegraf_processes_running:
        telegraf_status = tc = "ok"
        #tc = "ok"  # green
        #print (telegraf_status, tc, "GREEN")
        return (telegraf_status, tc)

#t_stat()

