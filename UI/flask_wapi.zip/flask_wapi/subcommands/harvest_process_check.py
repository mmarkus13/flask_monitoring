import subprocess, os

#def t_maint(maint):
    # check maint file if resource that runs the service is silenced currently
    # return maint_t

def h_stat():
    #harvest_ps_command = "ps -ef |grep -i harvest_dummy |grep -v grep" # or replace with 'systemctl status harvest'

    # bash commands:
    logfile = "/home/${USER}/UI/flask_wapi/harvest*_uptime.log"

    harvest_processes_c = ("cat "+logfile+"|tail -5 | sort -u | wc -l")
    harvest_processes_running_c = ("cat "+logfile+"|tail -5 | grep harvest | grep OK | wc -l")
    harvest_processes_o_c = ("cat "+logfile+"|tail -5 | grep harvest | grep -v OK")

    # variables with values:
    #status, harvest_ps_command_status = subprocess.getstatusoutput(harvest_ps_command)
    status, harvest_processes = subprocess.getstatusoutput(harvest_processes_c)
    status, harvest_processes_running = subprocess.getstatusoutput(harvest_processes_running_c)
    status, harvest_processes_o = subprocess.getstatusoutput(harvest_processes_o_c)

    #print ("processes",harvest_processes,"\n\nrunning",harvest_processes_running,"\n\noutage:\n",harvest_processes_o,"\n\n\n")

    if harvest_processes_running == 0:
        harvest_status = 0
        hc = "down"  # red
        #print (harvest_status, tc)
        return (harvest_status, hc)
    elif harvest_processes > harvest_processes_running:
        harvest_status = harvest_processes_o
        hc = "outage"  # yellow
        #print (harvest_status, tc)
        return (harvest_status, hc)
    elif harvest_processes == harvest_processes_running:
        harvest_status = hc = "ok"  # green
        #print (harvest_status, tc)
        return (harvest_status, hc)


