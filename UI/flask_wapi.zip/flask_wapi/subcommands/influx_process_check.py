import subprocess, os

#def i_maint(maint):
    # check maint file if resource that runs the service is silenced currently
    # return g_maint

def i_stat():
    logfile="/home/${USER}/UI/flask_wapi/influx_uptime.log"
    influx_ps_command = ("tail -1 "+logfile)

    status, influx_ps_command_status = subprocess.getstatusoutput(influx_ps_command)

    if influx_ps_command_status:
#        print (influx_ps_command_status)
        return (influx_ps_command_status)
   
    else:
        influx_ps_command_status = "down"
        print ("Influx is not running!")

        return (influx_ps_command_status)


def i_stat_latency():
    influx_latency_command = """ curl -s -w 'Establish Connection: %{time_connect}s\nTTFB: %{time_starttransfer}s\nTotal: %{time_total}s\n' 127.0.0.1:8086 | egrep "Total: [0-9]" | cut -d: -f2 | tr -d "s" """
    status, influx_latency_status = subprocess.getstatusoutput(influx_latency_command)

    if int(float(influx_latency_status)) > 1 :
        ic= "high"
        #print ("Latency", influx_latency_status, ic)
        return (influx_latency_status, ic)
 
    else:
        influx_latency_status = "ok"
        ic = "ok" 
        #print ("Latency", influx_latency_status, ic)
        return (influx_latency_status, ic)
