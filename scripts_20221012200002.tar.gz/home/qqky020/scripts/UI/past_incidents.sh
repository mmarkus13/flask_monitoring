#!/bin/bash


#set -x

# TIMER -start
res1=$(date +%s.%N)
# measure runtime of this script

flask_path="/home/qqky020/UI/flask_wapi_PROD"
cd $flask_path


past_incidents()

{

    for T in MONTH WEEKS DAYS;
        do declare t=${T,,};
            RANGE=$(date -d "$date -1 ${t}" +"%s");

            rm logfiles 2>/dev/null; for file in *.log; do echo $file >> logfiles; cat logfiles|sort -u > logfiles.list; done
            for service in grafana harvest influx telegraf; 
		do file=$(cat logfiles.list|grep $service); cat $file|egrep -i '(not|high)' | while read LINE;
		    do x=$(echo $LINE |cut -d'@' -f2 | cut -d' ' -f1); 
			if ! [[ $x == '' ]]; then y=$(date -d "$x" +"%s"); 
				if [ "$RANGE" -le "$y" ]; then echo $LINE >> incidents_${t}.csv; 
				fi; 
			fi; 
		    done; 
		done
        done

mv incidents_days.csv today.csv 2>/dev/null
mv incidents_weeks.csv weekly.csv 2>/dev/null
mv incidents_month.csv montly.csv 2>/dev/null
}


past_incidents


set +x

# TIMER STOP (calculate runtime):
res2=$(date +%s.%N)
dt=$(echo "$res2 - $res1" | bc)
dd=$(echo "$dt/86400" | bc)
dt2=$(echo "$dt-86400*$dd" | bc)
dh=$(echo "$dt2/3600" | bc)
dt3=$(echo "$dt2-3600*$dh" | bc)
dm=$(echo "$dt3/60" | bc)
ds=$(echo "$dt3-60*$dm" | bc)
echo
printf "script run for: %d:%02d:%02d:%02.4f\n" $dd $dh $dm $ds
echo

