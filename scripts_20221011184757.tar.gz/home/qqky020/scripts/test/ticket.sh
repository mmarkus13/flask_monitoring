#!/usr/bin/bash -x

get_token()
{
curl -v -k -s -d  '{"username":"qqky020","password":"T6HKyg_R5krd43k","tenantName":"*"}' -H "Content-Type: application/json" -X POST https://tsps-int.bmwgroup.net:8043/tsws/10.0/api/authenticate/login
}

send_event()
{
curl -v -s -k -d "@test_event.json" -H "Content-Type: application/json" -H "authorization: authToken _81f10100-6e7c-41e7-b902-d5ef766ba949" -X POST https://tsims1-int.bmwgroup.net:8443/bppmws/api/Event/create?routingId=iforwemcell10
}

incident_number()
{
curl -v -k -s -d "@ticket.json" -H "Content-Type: application/json" -H "authorization: authToken _81f10100-6e7c-41e7-b902-d5ef766ba949" -X POST https://tsims1-int.bmwgroup.net:8443/bppmws/api/Event/search?routingId=iforwemcell10
}

logout_token()
{
curl -v -k -s -d ‘{ “authToken”: “_81f10100-6e7c-41e7-b902-d5ef766ba949” }’ -H “Content-Type: application/json” -X POST https://tsps-int.bmwgroup.net:8043/tsws/10.0/api/authenticate/logout
}


get_token
#send_event
#incident_number
#logout_token


