#!/home/qqky020/miniconda3/bin/python

## OLD PATH was: ...anaconda3/bin/python

import pandas as pd 
import json 
import requests 
import pyodbc 

import os
#import sys
#print(sys.path)


import time 
start = time.time() 

# BASH STRING: isql -v -k "DRIVER={ODBC Driver 18 for SQL Server};SERVER=mvashhdnradp1,1433;UID=SelfBi_Monitor_Reader;PWD=Read2stClasses;Authentication=SqlPassword;TrustServerCertificate=Yes"
#bash_cmd = ' isql -v -k "DRIVER={ODBC Driver 18 for SQL Server};SERVER=mvashhdnradp1,1433;UID=SelfBi_Monitor_Reader;PWD=Read2stClasses;Authentication=SqlPassword;TrustServerCertificate=Yes"'

server = 'mvashhdnradp1' 
database = 'BMW_Common_View' 
username = 'SelfBi_Monitor_Reader' 
password = 'Read2stClasses' 
#cnxn = pyodbc.connect('DRIVER={SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password) 
#cnxn = pyodbc.connect('DRIVER={ODBC Driver 18 for SQL Server};SERVER='+server+',1433;UID='+username+';PWD='+ password +';Authentication=SqlPassword;TrustServerCertificate=Yes')
#cnxn = pyodbc.connect('DRIVER={ODBC Driver 18 for SQL Server};SERVER=mvashhdnradp1,1433;UID=SelfBi_Monitor_Reader;PWD=Read2stClasses;Authentication=SqlPassword;TrustServerCertificate=Yes')

cnxn = pyodbc.connect('Driver={ODBC Driver 18 for SQL Server};Server='+server+';Database=MSSQLTipsDB;UID='+username+';PWD='+password';Authentication=SqlPassword;TrustServerCertificate=Yes')

#cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};Dsn=DWH')



"""
drivers = [item for item in pyodbc.drivers()]
driver = drivers[-1]
print("driver:{}".format(driver))
server = 'mvashhdnradp1'
database = 'BMW_Common_View'
uid = 'SelfBi_Monitor_Reader'
pwd = 'Read2stClasses'
con_string = f'DRIVER={driver};SERVER={server};DATABASE={database};UID={uid};PWD={pwd}'
print(con_string)
cnxn = pyodbc.connect(con_string)
"""

#Get Dataframe 
df  = pd.read_sql("""SELECT *
  FROM [BMW_Common_View].[monitoring].[V_StorageClass] 
            """,cnxn) 

df.shape

