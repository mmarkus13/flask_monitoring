#!/bin/bash -x

#cd $flask_path
#cd /home/qqky020/UI/flask_wapi_UAT

create_event()
{
        # ADAPTER_HOST  ## Name of the host where the evet was created == Telegraf
        adapter_host=`hostname`

        # MSG
	if [[ "$service" == "telegraf" ]]; then resolver_team="Monitoring"; else resolver_team="Unix"; fi
	
	#msg_tmp="[$resolver_team] CRITICAL: $service is down $date"
	msg="ß$resolver_team¤ CRITICAL: $service is down DATE" #$date"
	#msg="TEST"
	echo MSG: "$msg"

        # CONTRACT_ID
        ENV="EU UAT"

        if [[ "$ENV" == "EU PROD" ]]; then contract_id="10APP12005500"
        elif [[ "$ENV" == "EU UAT" ]]; then contract_id="10APP12005501"
        elif [[ "$ENV" == "US" ]]; then contract_id="20APP12005500"
        elif [[ "$ENV" == "APAC" ]]; then contract_id="30APP12005500"
        fi
	echo contract_id: $contact_id


        # HOSTNAME  # UPDATE THIS ACCORDING YOUR ENVIRONMENT! (below values correspond to 'EU UAT'
        if [[ "$service" == "telegraf" ]]; then hname=`hostname` && event_id="11600"
        elif [[ "$service" == "grafana" ]]; then hname="ITAHDNASREP.bmwgroup.net" && event_id="11601"
        elif [[ "$service" == "influx" ]]; then hname="ITAHDNASREP.bmwgroup.net" && event_id="11602"
        elif [[ "$service" == "harvest" ]]; then hname="ITAHDNASUATHAR.bmwgroup.net" && event_id="11603"
        fi
	echo hostname: $hname
	echo event_id $event_id

    # SED process - create event.json from json.SED file
    cat json.SED > event.json
    for REPLACE in ADAPTER_HOST MSG CONTRACT_ID HNAME EVENT_ID SERVICE ; do replace=${REPLACE,,}; sed -i "s/${REPLACE}/${!replace}/g" event.json; done
    sed -i "s/ß/\[/g" event.json; sed -i "s/¤/\]/g" event.json
    sed -i "s/DATE/$(date +'%Y\/%m\/%d %H:%M:%S')/g" event.json
}

send_event_TO-REMEDY-DIRECTLY()
{
curl -v -s -k -d "@event.json" -H "Content-Type: application/json" -H "authorization: basic cXFreTAyMDpUNkhLeWdfUjVrcmQ0M0s= " -X POST https://tsims1-int.bmwgroup.net:8443/bppmws/api/Event/create?routingId=iforwemcell10
}


send_event()
{
	#echo
	curl -v -s -k -d "@event.json" -H "Content-Type: application/json"   -X POST http://itahdnasrep.bmwgroup.net:1880/influx2 # NODERED-test
}



for service in telegraf #etc...;
    do
	create_event
	send_event
    done


set +x
