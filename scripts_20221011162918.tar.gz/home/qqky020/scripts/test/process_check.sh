#!/bin/bash

cd "/home/qqky020/scripts/test"

p_check()
{
	PROCL=$(pstree -p)
	P_NUM=$(echo "$PROCL"|wc -l)

	if [[ "$P_NUM" -gt 1000 ]]; then echo -e "$PROCL\n\n$P_NUM @`date`\n" > `date +\%Y\%m\%d\%H\%M\%S`_processes.log; fi
} 

p_check > /dev/null 2>&1


