#!/bin/bash -x

# TIMER -start
res1=$(date +%s.%N)
# measure runtime of this script


DATE=`date +'%m/%d/%Y %H:%M:%S'`
err_msg="not running @$DATE"
ok_msg="OK @$DATE"

flask_path=/home/qqky020/UI/flask_wapi_UAT
cd $flask_path

#services="grafana harvest influx telegraf"
services="harvest"
service="harvest"

EPOCHNOW=`date -d "${DATE}" +"%s"`

    serviceup5min()
        {
        echo -e '\e[1A\e[Kchecking if any service was down for the past 5 consecutive minutes'
        echo -ne '######              (30%)\r'

        c=0  # counts how many times the app was down ruing the past 5 minutes (0 = no outage; 1..4 partial; 5 = app is down for 5 minutes)
        for((i=1;i<=5;++i))
            do
            stat=$(tac ${service}_uptime.log | sed -n "${i},1p")
            dat=$(echo $stat| cut -d@ -f2)
		echo -e "\n$i; $stat\n\n"
		case $stat in
                OK) return 1 ;;
                not)
                epoch_dat=`date -d "${dat}" +"%s"`
                    if [ "$(echo $EPOCHNOW-$epoch_dat|bc)" -le "360"  ] # less or equal to 360 seconds AKA 6 min (5min +1min grace time due to latency)
                    then c=$((c+1))
                    export c
                    if [ "$c" == 1 ]; then echo "donwtime `date  +"%m/%d %H:%M:%S"` /" >>  ${service}_downtime.rep; fi  # write to file when service is down; clear with external script in midnight...
                fi ;;
                esac
            done
        }

serviceup5min

set +x
