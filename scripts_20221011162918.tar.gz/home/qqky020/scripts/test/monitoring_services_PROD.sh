#!/bin/bash -x

# TIMER -start
res1=$(date +%s.%N)
# measure runtime of this script

DATE=`date +'%m/%d/%Y %H:%M:%S'`
err_msg="not running @$DATE"
ok_msg="OK @$DATE"

flask_path=/home/qqky020/UI/flask_wapi_PROD
cd $flask_path


# Define function to check service status:
services_check()
{

# ACTIVE_IQ
    # not defined yet

# GRAFANA:
    grafana_status()
    {
        grafana_url="https://grafana.apps.kynprodocp.bmwgroup.net/api/health"  # PROD (port is 443)
        grafana_check="$(curl -s $grafana_url | grep -oh [[:alpha:]]*ok[[:alpha:]]*)"  # checks if status is "ok"
        grafana_latency=$(curl -s -w 'Establish Connection: %{time_connect}s\nTTFB: %{time_starttransfer}s\nTotal: %{time_total}s\n' itahdnasrep.bmwgroup.net:3000/ping/api/health | egrep "Total: [1-9]") ;  # checks if latency is above 1 second
        # log status:
        [ $(eval echo \$"${service}_check") == 'ok' ] && [ -z "$latency" ] || echo -e "\n$DATE\n$grafana_check\n\n###" >> ${service}_high_latency.log && echo "${service} $ok_msg" >> ${service}_uptime.log || echo "${service}" $err_msg >> ${service}_uptime.log
        export grafana_latency
    }

# HARVEST:
    harvest_status()
    {
        for H in lvashhdnharp00 lvashhdnharp01 lvashhdnharp02 lvashhdnharp03 lvashhdnharp04 lvashhdnharp05 lvashhdnharp06;
#        for H in "$HARVEST_HOSTS";
            do
                harvest_status="$(echo T6HKyg_R5krd43K  | /home/qqky020/scripts/.hrp ssh qqky020@${H} 'systemctl status harvest')"
                echo "$harvest_status" > harvest_status_${H}.txt
                harvest_check=$(echo "$harvest_status" | sort -u | grep running | wc -l)
                if ! [ "$(echo $harvest_check)" == 1 ]; then echo "${service}" $err_msg >> ${service}_${H}_uptime.log; else echo "${service} $ok_msg" >> ${service}_${H}_uptime.log; fi
            done
                harvest_status="$(cat harvest_status*.txt)"; export harvest_status
    }

# INFLUX:
    influx_status()
    {
        influx_url="https://influxdb.apps.kynprodocp.bmwgroup.net/health"  # PROD (port is 443)
        influx_check="$(curl -s $influx_url | grep status |  grep -oh [[:alpha:]]*pass[[:alpha:]]*)"  # check if status is "pass"
        influx_latency=$(curl -s -w 'Establish Connection: %{time_connect}s\nTTFB: %{time_starttransfer}s\nTotal: %{time_total}s\n' itahdnasrep.bmwgroup.net:8086 | egrep "Total: [1-9]")
        [ $(eval echo \$"${service}_check") == 'pass' ] && [ -z "$latency" ] || echo -e "\n$DATE\n${service}_check\n\n###" >> ${service}_high_latency.log && echo "${service} $ok_msg" >> ${service}_uptime.log || echo "${service}" $err_msg  >> ${service}_uptime.log

        influx_bucket_write_check="$(cat /etc/telegraf/logs/*.log | grep -i "error writing" | egrep "`date +'%Y-%m'`" | egrep `date +'%H:%M:'` | wc -l)"
        if [ "$(echo $harvest_check)" == 0 ]; then influx_bucket_write_status="Write ERROR"; fi
        export influx_latency influx_bucket_write_status
    }

echo $influx_bucket_write_status

# NodeRed
    # not defined

# TELEGRAF:
    telegraf_status()
    {
        telegraf_check="$(systemctl | grep telegraf | sort -u | grep -v running | wc -l)"
        if ! [ "$(echo $telegraf_check)" == 0 ]; then echo "${service}" $err_msg >> ${service}_uptime.log; else echo "${service} $ok_msg" >> ${service}_uptime.log; fi
        export telegraf_check
    }

# LOOP OVER SERVICES to check status:
for service in grafana harvest influx telegraf #active_iq harvest nodered
    do
        ${service}_status
    done
}


# send ticket (directly to Remedy) if service is down for 5 consecutive minutes
ticket()
{
EPOCHNOW=`date -d "${DATE}" +"%s"`

    serviceup5min()
        {
        c=0  # counts how many times the app was down ruing the past 5 minutes (0 = no outage; 1..4 partial; 5 = app is down for 5 minutes)
        for((i=1;i<=5;++i))
            do
            stat=$(tac ${service}_uptime.log | sed -n "${i},1p")
            dat=$(echo $stat| cut -d@ -f2)
                case $stat in
                OK) return 1 ;;
                not)
                epoch_dat=`date -d "${dat}" +"%s"`
                    if [ "$(echo $EPOCHNOW-$epoch_dat|bc)" -le "360"  ] # less or equal to 360 seconds AKA 6 min (5min +1min grace time due to latency)
                    then c=$((c+1))
                    export c
                    if [ "$c" == 1 ]; then echo "donwtime `date  +"%m/%d %H:%M:%S"` /" >>  ${service}_downtime.rep; fi  # write to file when service is down; clear with external script in midnight...
                fi ;;
                esac
            done
        }


        create_event()  # only create & send event if it is down for 5 consecutive minutes
                {
                set -x
                        if [[ $c -ne 5 ]]; then return 1  # debug mode is: "-eq"; normal mode is: "-ne"
                        else
                                # ADAPTER_HOST  ## Name of the host where the evet was created == Telegraf
                                adapter_host=`hostname`

                                # MSG
                                if [[ "$service" == "telegraf" ]]; then resolver_team="Monitoring"; else resolver_team="Unix"; fi

                                #msg_tmp="[$resolver_team] CRITICAL: $service is down $date"
                                msg="ß$resolver_team¤ CRITICAL: $service is down DATE" #$date"

                                # CONTRACT_ID
                                ENV="EU PROD"

                                if [[ "$ENV" == "EU PROD" ]]; then contract_id="10APP12005500"
                                elif [[ "$ENV" == "EU UAT" ]]; then contract_id="10APP12005501"
                                elif [[ "$ENV" == "US" ]]; then contract_id="20APP12005500"
                                elif [[ "$ENV" == "APAC" ]]; then contract_id="30APP12005500"
                                fi

                                # HOSTNAME  -- UPDATE THIS ACCORDING YOUR ENVIRONMENT! (below values correspond to 'EU PROD'
                                if [[ "$service" == "telegraf" ]]; then hname=`hostname` && event_id="11610"
                                elif [[ "$service" == "grafana" ]]; then hname="kynprodocp.bmwgroup.net" && event_id="11611"
                                elif [[ "$service" == "influx" ]]; then hname="kynprodocp.bmwgroup.net" && event_id="11612"
                                elif [[ "$service" == "harvest" ]]; then H=$(find /home/qqky020/UI/flask_wapi_PROD/  -name 'harvest*.log' -exec grep 'not running' {} \;  -print | grep -A1 `date "+%m/%d/%Y %H:%M"` | grep log | sort -u | cut -d_ -f4);  hname=$H && event_id="11613"
                                fi
                                echo hostname: $hname  # debug purpose
                                echo event_id $event_id  # debug purpose

                   # SED process - create event.json from json.SED file
                                cd /home/qqky020/scripts/ticket
                                cat json.SED > event.json
                                for REPLACE in ADAPTER_HOST MSG CONTRACT_ID HNAME EVENT_ID SERVICE ; do replace=${REPLACE,,}; sed -i "s/${REPLACE}/${!replace}/g" event.json; done
                                sed -i "s/ß/\[/g" event.json; sed -i "s/¤/\]/g" event.json
                                sed -i "s/DATE/$(date +'%Y\/%m\/%d %H:%M:%S')/g" event.json

                                cd -
                        fi
                }


    send_event()
        {
                curl -v -s -k -d "@/home/qqky020/scripts/ticket/event.json" -H "Content-Type: application/json" -H "authorization: basic cXFreTAyMDpUNkhLeWdfUjVrcmQ0M0s= " -X POST https://tsims1-int.bmwgroup.net:8443/bppmws/api/Event/create?routingId=iforwemcell10
        }


    for service in grafana harvest influx telegraf #harvest #ansible nodered
        do
            serviceup5min && create_event #&& send_event
        done
}



manage_logs()
    {
        # GENERATE UPTIME LOGS FOR FLASK
        service_uptime()  # Grafana & Influx
        {
                if [[ "$service" = "telegraf" ]]; then
                telegraf_sub_service_upt()
                    {
                    #set -x
                    stat=`systemctl status telegraf_${sub}.service`
                    #echo $stat
                    [[ $(echo "$stat" | grep "running") == *running* ]] && r="Running" || r="Down"
                    since=$(echo $stat | grep -Po ".*; \K(.*)(?= ago)")
                    epoch_since=$(date --date="$since" +"%s")

                    uptime_seconds=`echo $epoch_since - $EPOCHNOW | bc`
                    uptime=$(echo $uptime_seconds/60|bc)  # minutes

                    REPORT=$(date --date="$since" +"%Y-%m-%d %H:%M:%S")

                    echo -e "$r|since $uptime minutes|"$REPORT > telegraf_${sub}_uptime.txt

                    }

                for sub in esx system traps  #broadcom cisco esx storage system traps
                do
                    telegraf_sub_service_upt
                done


                elif [[ "$service" = "harvest" ]]; then
                harvest_services_upt()
                    {
                    #set -x
                    #stat=`systemctl status harvest.service`
                    stat="$harvest_status"
                    #echo "$stat"  # debug mode
                    [[ $(echo "$stat" | grep "running") == *running* ]] && r="Running" || r="Down"
                    since=$(echo $stat | grep -Po ".*; \K(.*)(?= ago)")
                    epoch_since=$(date --date="$since" +"%s")

                    uptime_seconds=`echo $epoch_since - $EPOCHNOW | bc`
                    uptime=$(echo $uptime_seconds/60|bc)  # minutes

                    REPORT=$(date --date="$since" +"%m/%d %H:%M:%S")

                    echo -e "$r|since $uptime minutes|"$REPORT > harvest_uptime.txt

                    }

                harvest_services_upt


                else
                #set -x
                last=$(tac ${service}_uptime.log | grep -A1 -m 1 "not")  # sample: grafana OK @08/11/2022 17:28:03
                up=$(echo "$last" | tail -1)
                epoch_up=`date -d "$(echo $up | cut -d@ -f2)" +"%s"`
                down=$(echo "$last" | head -1)
                epoch_down=`date -d "$(echo $down | cut -d@ -f2)" +"%s"`
                prev_down=$(tac ${service}_uptime.log | grep -m 2 "not" | tail -1)
                epoch_prev_down=`date -d "$(echo $prev_down | cut -d@ -f2)" +"%s"`
                seconds=`echo "$epoch_down"-"$epoch_prev_down"|bc`

                if [[ "$seconds" -eq 0 ]]
                        then echo "UNKNOWN" > ${service}_uptime.txt
                else
                        downtime_minutes=$(echo $seconds/60|bc)
                        service_uptime=`echo $(echo "$EPOCHNOW"-"$epoch_up"|bc)/60|bc`

                        REPORT=$(date --date="$service_uptime" +"%m/%d %H:%M:%S")

                        echo -e "Down: $down|Up:$up\nOutage Time: $last_outage minutes|$REPORT" > ${service}_uptime.txt
                fi
            fi
        }

       for service in grafana harvest influx telegraf #.....
        do
          service_uptime
        done


        past_incidents()
        {
            for T in DAYS WEEKS MONTH;
            do declare t=${T,,};
                RANGE=$(date -d "$date -1 ${t}" +"%s");

                ls *uptime.log | xargs cat | grep -v OK | sort -u | while read line;
                do
                    x=$(echo $line |cut -d@ -f2)
                    if ! [[ $x == '' ]]; then
                        y=$(date -d "$x" +"%s")
                        if [ "$RANGE" -le "$y" ]; then  echo $line >> incidents_${t}.csv; fi
                    fi
                done
            done


        mv incidents_days.csv today.csv 2>/dev/null
        mv incidents_weeks.csv weekly.csv 2>/dev/null
        mv incidents_month.csv montly.csv 2>/dev/null
        }

    # call past incidents subfunction
    past_incidents

}

# Run main parts of the script:
services_check
ticket
manage_logs


# TIMER STOP (calculate runtime):
res2=$(date +%s.%N)
dt=$(echo "$res2 - $res1" | bc)
dd=$(echo "$dt/86400" | bc)
dt2=$(echo "$dt-86400*$dd" | bc)
dh=$(echo "$dt2/3600" | bc)
dt3=$(echo "$dt2-3600*$dh" | bc)
dm=$(echo "$dt3/60" | bc)
ds=$(echo "$dt3-60*$dm" | bc)
echo
printf "script run for: %d:%02d:%02d:%02.4f\n" $dd $dh $dm $ds
echo
set +x

#exit 0

