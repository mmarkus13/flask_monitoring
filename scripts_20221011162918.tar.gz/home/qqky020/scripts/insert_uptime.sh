#!/bin/bash

#cd $flask_path
cd /home/qqky020/UI/flask_wapi_UAT

echo "" | tee ./*downtime.rep > /dev/null

downtime_check=$(cat *_uptime.txt |  awk '{print $2}' | grep [0-9] |sort -n | head -1)
if [[ " $downtime_check" -lt  "1440" ]]  # if outage happened within the past 24 hours
 then	for service in grafana harvest influx telegraf;
		do start_time=$(cat ${service}_downtime.rep); end_time=$(cat ${service}_*uptime.txt|cut -d'|' -f3 | sort -n | tail -1); date_check=$(echo $end_time | grep [0-9])
			#if [[ -z "$date_check" ]]; then end_time=$(echo `date +"%Y-%m-%d"` 23:59:59); fi
			if [[ -z "$date_check" ]]; then end_time=$(echo `date +%Y-%m-%d -d "yesterday"` 23:59:59); fi  # as this script is scheduled (cron) to run after midnight

			if [[ $service = "grafana" ]]; then pfrx="graf" 
			elif [[ $service = "harvest" ]]; then prfx="hv"
			elif [[ $service = "influx" ]]; then prfx="infl"
			elif [[ $service = "harvest" ]]; then prfx="tg"
			fi

			sql="INSERT INTO [Availability_ST1].[dbo].[APORTAL_INPUT_OUTAGES_TMP]([DWH_Key],[DWH_CreatedBy],[DWH_CreatedDate],[ServerName],[InterruptionStart_UTC],[InterruptionEnd_UTC],[TicketNo]) VALUES ('ITAHDNASUATTEL.bmwgroup.net|$service|$start_time', 'insert_uptime.sh', {ts'`date +"%Y-%m-%d %H:%M:%S"`'}, '${prfx}_ITAHDNASUATTEL', {ts'$start_time'}, {ts'$end_time'}, null)"

			echo "$sql" > uptime.sql
			query < uptime.sql
			echo Donwtime report sent to database at `date +"%Y-%m-%d %H:%M:%S"` >> database_downtime_insertions.log
		done
 else
	echo No downtime in the past 24 hours.
fi

