#!/usr/bin/python
#------------------------------------------------------------------------------#
#  File      :                                                                 #
#  Project   : BMW                                                             #
#  Author    : Michal Markus                                                   #
#  Date      : 25/07/2022                                                      #
#  Version   : 1.04                                                            #
#------------------------------------------------------------------------------#
#  SCRIPT DESCRIPTION                                                          #
#------------------------------------------------------------------------------#
#                                                                              #
#  Parameters :                                                                #
#  Synopsis   : Checks if monitoring related services are running              #
#  Environment: Test                                                           #
#                                                                              #
#------------------------------------------------------------------------------#
#  HISTORY OF CHANGES :                                                        #
#------------------------------------------------------------------------------#
#   Date    Author          Version   Modification                             #
#                                                                              #
#------------------------------------------------------------------------------#

#------------------------------------------------------------------------------#
#import for base flask functionality
from application import app
from flask import render_template, request, json, Response, url_for, redirect
#------------------------------------------------------------------------------#
#import for custom                                                             #
import subprocess, time, sys, os, glob                                         #
from os import path                                                            #
from my_functions.usrch import usercheck                                       #
from my_functions.pyver import *						                       #
#import my_functions.boolconv 				                                    #
#------------------------------------------------------------------------------#

"""to be changed to qq user:"""
usercheck()                                                                    #exit if not launched via qq user - commented during testPhase on localmachine

#------------------------------------------------------------------------------#

import logging
"""the below escalates into huge file quite quickly.."""
#logging.basicConfig(filename='flask_debug.log', level=logging.DEBUG)

logging.basicConfig(filename='flask_info.log',
level=logging.INFO,
format='%(asctime)s %(levelname)s %(name)s %(threadName)s : %(message)s')

"""Unnecessary for now (leaving the code here in case we'd like to pull reports via this API)
#------------------------------------------------------------------------------#
#---Limit_Requests
from flask import Flask
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

#app = Flask(__name__)
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

def host_scope(endpoint_name):
    return request.host

#host_limit = limiter.shared_limit("3/hour", scope=host_scope)
#@limiter.limit("100/day", exempt_when=lambda: current_user.is_admin)
host_limit = limiter.shared_limit("10/hour", scope=host_scope) #, exempt_when=lambda: request.host="127.0.0.1:8000")
#limiter.exempt(request.host="127.0.0.1:8000")
"""
#------------------------------------------------------------------------------#
#---FAVICON
import os
from flask import send_from_directory

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'),
                          'favicon.ico',mimetype='image/vnd.microsoft.icon')
#------------------------------------------------------------------------------#
#---Home page & Monitoring services

# - Get status (this can be replaced by reading current log file generated via cron)
#from subcommands.activeiq_process_check import aiq_stat
from subcommands.grafana_process_check import g_stat, g_stat_latency
#from subcommands.harvest_process_check import h_stat
from subcommands.influx_process_check import i_stat, i_stat_latency
from subcommands.telegraf_process_check import t_stat

@app.route("/")                                                                # homepage
@app.route("/infra")    
#@app.route("/infra", methods=["GET","POST"])                                  # not posting anything right now
#@host_limit        # limit requests per host
#@limiter.exempt    # disable all kind of limiting for current page
def infra():
    logging.info("\nUser = "+request.host+"\nPage = infra\n")                  # save IP to log
    print("\nUser = "+request.host+"\nPage = infra\n")                         # print to flask terminal

#    return render_template("infra.html", infra=True)         s                  # infra=True is needed for ..\application\nav.html so that the active window is highlighted

#### Updated template:

#services = [ "grafana", "influx", "harvest", "telegraf" ]  # "ansible", "nodered"     

#for service in services:
#service_status  

    maint= "off"
    
    #g_maint = g_stat(maint)
    grafana_status = g_stat()
    grafana_latency_output = g_stat_latency()
    grafana_latency = (grafana_latency_output[1])
    gc = (grafana_latency_output[0])

    #h_maint = h_stat(maint)
    ## 0 is placeholder for now, will pwless ssh or other solution in place...
    harvest_status = 0 #h_stat()

    #i_maint= i_stat(maint)
    influx_status = i_stat()
    influx_latency_output = i_stat_latency()
    influx_latency = (influx_latency_output[1])
    ic = (influx_latency_output[0])

    #t_maint= t_stat(maint)
    telegraf_status = t_stat()

    return render_template("infra.html", grafana_status=grafana_status, grafana_latency=grafana_latency, gc=gc, harvest_status=harvest_status, influx_status=influx_status, influx_latency=influx_latency, ic=ic, telegraf_status=telegraf_status, infra=True)  # ...maint="t_maint",

#------------------------------------------------------------------------------#
#---BMW Monitoring Services that needs to be added to above section:

#grafana
#harvest
#influx
#nodered
#telegraf

#------------------------------------------------------------------------------#
#---Ansible
#@app.route("/ansible")
#def ansible():
#    return render_template("ansible.html", ansible=True)
    # jobok státusza

#------------------------------------------------------------------------------#
#---Past_Incidents
@app.route("/past_incidents")
def past_incidents():
    #return render_template("past_incidents.html", past_incidents=True)
    # ...
    with open("today.csv", "r") as f: 
        content_day = f.read() 

    with open("weekly.csv", "r") as f: 
        content_week = f.read() 

    with open("montly.csv", "r") as f: 
        content_month = f.read()     

    #return render_template("template.html", content=content) 
    return render_template("past_incidents.html", past_incidents=True, content_day=content_day, content_week=content_week, content_month=content_month)



"""OR VIA DOWLNLOAD"""
"""
from flask import Flask
from flask import send_file
app = Flask(__name__)

@app.route('/download')
def downloadFile ():
    #For windows you need to use drive name [ex: F:/Example.pdf]
    path = "/Examples.pdf"
    return send_file(path, as_attachment=True)
"""


#------------------------------------------------------------------------------#
#---Maintenance
@app.route("/maintenance")
def maintenance():
    with open("maintenance.csv", "r") as f:
        maintenance_info = f.read()
    return render_template("maintenance.html", maintenance=True, maintenance_info=maintenance_info)

    # ... 


### DOWNLOAD TEST
app.config['UPLOAD_FOLDER']='csv'

#@app.route('/uploads/<path:filename>', methods=['GET', 'POST'])
#def download(filename):
#    print(app.root_path)
#    full_path = os.path.join(app.root_path, app.config['UPLOAD_FOLDER'])
#    print(full_path)
#    return send_from_directory(full_path, filename)
###

#current_app = Flask(__name__)


#@app.route('/uploads/<path:filename>', methods=['GET', 'POST'])
#def download(filename):
#    uploads = os.path.join(current_app.root_path, app.config['UPLOAD_FOLDER'])
#    return send_from_directory(directory=uploads, filename=filename)

###
#from flask import send_file
#app = current_app = Flask(__name__)
#@app.route('/download')
#def downloadFile ():
#    uploads = os.path.join(current_app.root_path, app.config['UPLOAD_FOLDER'])
#return send_from_directory(directory=uploads, filename=filename)
#    return send_file(uploads, as_attachment=True)

###
#import flask
#from flask import Flask
#from flask import Flask
#from flask import send_file
#app = Flask(__name__)
#import flask
#from flask import Flask
#app = Flask(name)   

#@app.route('/download')
#def downloadFile ():
    #For windows you need to use drive name [ex: F:/Example.pdf]
#    path = "/monthly.csv"
#    return send_file(path, as_attachment=True)



###########################
from flask import Flask, current_app
@app.route('/csv/<path:filename>', methods=['GET', 'POST'])
def download(filename):
    # Appending app path to upload folder path within app root folder
    uploads = os.path.join(current_app.root_path, app.config['UPLOAD_FOLDER'])
    # Returning file from appended path
    return send_from_directory(directory=uploads, filename=filename)
