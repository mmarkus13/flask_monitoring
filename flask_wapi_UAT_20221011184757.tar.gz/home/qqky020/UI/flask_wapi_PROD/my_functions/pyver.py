import sys, subprocess

""" Check default python """
wpcmd = "/bin/bash -c 'which python'"                                                           #[W]hich [P]ython [c]o[m]man[d]
if sys.version_info >= (3, 0):
    status, vpy = subprocess.getstatusoutput(wpcmd)
else:
    import commands
    status, vpy = commands.getstatusoutput(wpcmd)


""" Define custom commands for the script to handle any py version """
"""
def pyv23():
###     ---PYTHON3---   ###                                                                     PATH = /opt/IBM/scanalytics/anaconda3/bin/python
    if sys.version_info >= (3, 0):
        def read( str ):
            userinput = input ( str )
            return userinput
        def getstat( str ):
            status, cmdoutput = subprocess.getstatusoutput( str )
            return cmdoutput
    else:
###     ---PYTHON2---   ###                                                                     PATH = /usr/bin/python
        def read( str ):
            userinput = raw_input ( str )
            return userinput
        def getstat( str ):
            status, cmdoutput = commands.getstatusoutput( str )
            return cmdoutput
"""


""" Define custom commands for the script to handle any py version """                          #input is not needed from user after arguments are set
###     ---PYTHON3---   ###                                                                     PATH = /opt/IBM/scanalytics/anaconda3/bin/python
if sys.version_info >= (3, 0):
    def read( str ):
        userinput = input ( str )
        return userinput
    def getstat( str ):
        status, cmdoutput = subprocess.getstatusoutput( str )
#        print (cmdoutput)
        return cmdoutput

else:
###     ---PYTHON2---   ###                                                                     PATH = /usr/bin/python
    def read( str ):
        userinput = raw_input ( str )
        return userinput
    def getstat( str ):
        status, cmdoutput = commands.getstatusoutput( str )
        return cmdoutput
