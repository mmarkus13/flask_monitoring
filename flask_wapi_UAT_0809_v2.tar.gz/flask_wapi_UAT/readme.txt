.flaskenv				#specifies "flask run" parameters; port & main.py to be runned
requirements.txt 		#pip freeze > requirements.txt ##to save; #pip install -r requirements.txt ##to install
						#or if server is not connected to INTERnet, then install the provided packages locally via 'pip install Flask_Login-0.5.0-py2.py3-none-any.whl'\or\'tar.gz'

main.py
application/
    __init__.py			#calls routes.py
	routes.py			#renders specified /templates/*.html and calls specified ../*.py
pi_event_extractor.py
readme.txt