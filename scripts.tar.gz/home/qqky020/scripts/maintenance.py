#!/home/qqky020/miniconda3/bin/python

import pandas as pd 
import json 
import requests 
import pyodbc 
import os
import subprocess
from io import StringIO

import time
start = time.time()

status, maint_df = subprocess.getstatusoutput('query_maint')
DATA = StringIO(maint_df)
df = pd.read_csv(DATA, sep=",")
df.to_csv('/home/qqky020/UI/flask_wapi_PROD/maintenance.csv', index=False)
#df.shape

