SELECT * FROM BMW_Common_View.monitoring.V_StorageClass
