def bool_to_word(bool):
    if bool == True:
        return "Yes"
    else:
        return "No"
