import timeit


""" Measure runtime """
start = timeit.default_timer()                                                                  #timer start
""" Stop timer & print elapsed time """
def stoprt():
    stop = timeit.default_timer()                                                               #timer stop
    elapsed = str(round(stop - start))                                                          #round to 0 digits
    print('\nscript runtime:', elapsed, 'seconds')                                              #show runtime


# Put your code here; and ucomment stoprt() below to measure runtime


#stoprt()                                                                                        #timer stop
