import subprocess, os

#def maint():
    # check maint file if resource that runs the service is silenced currently
    # return maint_t

def t_stat():
    
    telegraf_ps_command = "ps -ef |grep -i telegraf_dummy |grep -v grep" # or replace with 'systemctl status telegraf'
    status, telegraf_ps_command_status = subprocess.getstatusoutput(telegraf_ps_command)

    if telegraf_ps_command_status:
        print (telegraf_ps_command_status)
        return (telegraf_ps_command_status)
    else:
        telegraf_ps_command_status = "Telegraf not running!"
        print ("Telegraf is not running!")
        #the following part should be handled only by cron and not flask
        bash_log_command = "echo Telegraf not running @:`date` >> telegraf_uptime.log"  # | ./logwrapper program.log 100000 10 1"
        os.system(bash_log_command)
        #cron runs this script every miniute; 
            #5 consecutive occurrences = ticket
            #new logfile is created when it reaches 10mb
        return (telegraf_ps_command_status)