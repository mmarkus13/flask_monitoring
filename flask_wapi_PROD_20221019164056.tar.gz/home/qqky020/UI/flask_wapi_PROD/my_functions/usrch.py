import getpass

""" USER Check """
def usercheck():
    if getpass.getuser() != "qqky020@europe.bmw.corp":
        print ("To run this script switch your current user to qqky020!\nsu - qqky020")
        exit()
