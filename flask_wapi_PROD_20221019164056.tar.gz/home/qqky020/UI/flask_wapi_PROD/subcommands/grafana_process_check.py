import subprocess, os

#def g_maint(maint):
    # check maint file if resource that runs the service is silenced currently
    # return g_maint




def g_stat():
    logfile="/home/qqky020/UI/flask_wapi_UAT/grafana_uptime.log"
    grafana_ps_command = ("tail -1 "+logfile)

    status, grafana_ps_command_status = subprocess.getstatusoutput(grafana_ps_command)

    if grafana_ps_command_status:
#        print (grafana_ps_command_status)
        return (grafana_ps_command_status)
   
    else:
        grafana_ps_command_status = "down"
        print ("Grafana is not running!")

        return (grafana_ps_command_status)


def g_stat_latency():
    grafana_latency_command = """ curl -s -w 'Establish Connection: %{time_connect}s\nTTFB: %{time_starttransfer}s\nTotal: %{time_total}s\n' itahdnasrep.bmwgroup.net:3000/ping/api/health | egrep "Total: [0-9]" | cut -d: -f2 | tr -d "s" """
    status, grafana_latency_status = subprocess.getstatusoutput(grafana_latency_command)

#    print(grafana_latency_status)

    if int(float(grafana_latency_status)) > 1 :
        gc = "high"
#        print ("Latency",grafana_latency_status, gc)  # gc is passed on to routes.py which passes the variable to infra.html -- gc represents [G]rafana status [C]olor
        return (grafana_latency_status, gc)
 
    else:
        grafana_latency_status = "ok"
        gc= "ok"
#        print (grafana_latency_status, gc)
        return (grafana_latency_status, gc)
