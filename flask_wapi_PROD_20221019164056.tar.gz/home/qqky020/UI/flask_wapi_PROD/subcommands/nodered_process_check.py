import subprocess, os

#def t_maint(maint):
    # check maint file if resource that runs the service is silenced currently
    # return maint_t

def n_stat():
    #nodered_ps_command = "ps -ef |grep -i nodered_dummy |grep -v grep" # or replace with 'systemctl status nodered'

    # bash commands:
    logfile = "/home/qqky020/UI/flask_wapi_PROD/nodered_uptime.log"

    nodered_processes_c = ("tail -5 "+logfile+"| sort -u | wc -l")
    nodered_processes_running_c = ("tail -5 "+logfile+" | grep nodered | grep OK | wc -l")
    nodered_processes_o_c = ("tail -5 "+logfile+" | grep nodered | grep -v OK")

    # variables with values:
    #status, nodered_ps_command_status = subprocess.getstatusoutput(nodered_ps_command)
    status, nodered_processes = subprocess.getstatusoutput(nodered_processes_c)
    status, nodered_processes_running = subprocess.getstatusoutput(nodered_processes_running_c)
    status, nodered_processes_o = subprocess.getstatusoutput(nodered_processes_o_c)

    #print ("processes",nodered_processes,"\n\nrunning",nodered_processes_running,"\n\noutage:\n",nodered_processes_o,"\n\n\n")

    if nodered_processes_running == 0:
        nodered_status = 0
        nc = "down"  # red
        #print (nodered_status, tc, "RED")
        return (nodered_status, nc)
    elif nodered_processes > nodered_processes_running:
        nodered_status = nodered_processes_o
        nc = "outage"  # yellow
        #print (nodered_status, tc, "YELLOW")
        return (nodered_status, nc)
    elif nodered_processes == nodered_processes_running:
        nodered_status = nc = "ok"
        #tc = "ok"  # green
        #print (nodered_status, tc, "GREEN")
        return (nodered_status, nc)

