import getpass

""" USER Check """
def scadminch():
    if getpass.getuser() != "scadmin":
        print ("To run this script switch your current user to scadmin!\nsu - scadmin")
        exit()
